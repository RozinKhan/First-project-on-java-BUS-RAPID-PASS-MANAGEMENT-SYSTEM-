

package gui;
import repository.*;
import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;

public class Register extends JFrame implements ActionListener {
    private JPanel mainP, loginSide;
    private JLabel idL, passL, roleL, showloginL, nameL, securityAnsL;
    private JTextField idF, nameF, securityAnsF;
    private JPasswordField passF;
    private JButton loginB, registerB;
    private ImageIcon icon, icon1;
    private Image show, hide;
    private Font font14;

    public Register() {
        icon = new ImageIcon("icon/show.png");
        show = icon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);

        icon1 = new ImageIcon("icon/hide.png");
        hide = icon1.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);

        font14 = new Font("Times New Roman", Font.BOLD, 14);

        this.setSize(660, 420);
        this.setTitle("Register page");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        mainP = new JPanel();
        mainP.setLayout(null);
        mainP.setBackground(Color.gray);
        mainP.setBounds(0, 0, 660, 580);

        showloginL = new JLabel("Register-Page");
        showloginL.setBounds(290, 50, 90, 30);
        showloginL.setFont(font14);
        mainP.add(showloginL);

        loginSide = new JPanel();
        loginSide.setLayout(null);
        loginSide.setBounds(0, 0, 660, 580);
        mainP.add(loginSide);

        idL = new JLabel("Id: ");
        idL.setBounds(230, 100, 80, 30);
        idL.setFont(font14);
        loginSide.add(idL);

        idF = new JTextField();
        idF.setBounds(340, 100, 120, 30);
        idF.setBorder(BorderFactory.createLineBorder(null));
        idF.setFont(font14);
        loginSide.add(idF);

        nameL = new JLabel("Name: ");
        nameL.setBounds(230, 140, 80, 30);
        nameL.setFont(font14);
        loginSide.add(nameL);

        nameF = new JTextField();
        nameF.setBounds(340, 140, 120, 30);
        nameF.setBorder(BorderFactory.createLineBorder(null));
        nameF.setFont(font14);
        loginSide.add(nameF);

        roleL = new JLabel("Role: ");
        roleL.setBounds(230, 180, 80, 30);
        roleL.setFont(font14);
        loginSide.add(roleL);

        JTextField roleF = new JTextField("3"); 
        roleF.setBounds(340, 180, 120, 30);
        roleF.setBorder(BorderFactory.createLineBorder(null));
        roleF.setFont(font14);
        roleF.setEditable(false);
        loginSide.add(roleF);

        securityAnsL = new JLabel("Security Ans: ");
        securityAnsL.setBounds(230, 220, 100, 30);
        securityAnsL.setFont(font14);
        loginSide.add(securityAnsL);

        securityAnsF = new JTextField();
        securityAnsF.setBounds(340, 220, 120, 30);
        securityAnsF.setBorder(BorderFactory.createLineBorder(null));
        securityAnsF.setFont(font14);
        loginSide.add(securityAnsF);

        passL = new JLabel("Password: ");
        passL.setBounds(230, 260, 80, 30);
        passL.setFont(font14);
        loginSide.add(passL);

        passF = new JPasswordField();
        passF.setBounds(340, 260, 120, 30);
        passF.setBorder(BorderFactory.createLineBorder(null));
        passF.setFont(font14);
        loginSide.add(passF);

        registerB = new JButton("Confirm Registration");
        registerB.setBounds(170, 330, 150, 40);
        registerB.setBackground(new Color(0x358790));
        registerB.setForeground(Color.white);
        registerB.setFont(font14);
        registerB.setBorder(BorderFactory.createLineBorder(null));
        loginSide.add(registerB);

        loginB = new JButton("Back");
        loginB.setBounds(385, 330, 115, 40);
        loginB.setBackground(new Color(0x358790));
        loginB.setForeground(Color.white);
        loginB.setFont(font14);
        loginB.setBorder(BorderFactory.createLineBorder(null));
        loginSide.add(loginB);

        registerB.addActionListener(this);
        loginB.addActionListener(this);
        this.add(mainP);
        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == registerB) {
            String id = idF.getText();
            String name = nameF.getText();
            String role = "3"; 
            String securityAns = securityAnsF.getText();
            String password = new String(passF.getPassword());

            if (id.isEmpty() || name.isEmpty() || securityAns.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.");
                return;
            }

            String userInfo = String.format("%s,%s,%s,%s,%s", id, name, role, securityAns, password);

            try (BufferedWriter writer = new BufferedWriter(new FileWriter("repository/data/registerUser.txt", true))) {
                writer.write(userInfo);
                writer.newLine();
                JOptionPane.showMessageDialog(this, "Your registration is completed.");
                
                try (BufferedWriter userWriter = new BufferedWriter(new FileWriter("repository/data/user.txt", true))) {
                    userWriter.write(userInfo);
                    userWriter.newLine();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(this, "Error saving user information to user.txt.");
                }
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error saving user information.");
            }
        }

        if (e.getSource() == loginB) {
            Login loginFrame = new Login();
            this.setVisible(false);
            loginFrame.setVisible(true);
        }
    }
}
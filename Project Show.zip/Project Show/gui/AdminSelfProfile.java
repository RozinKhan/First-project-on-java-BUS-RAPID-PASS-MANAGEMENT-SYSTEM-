


package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class AdminSelfProfile extends JFrame {
    private JPanel mainP;
    private JLabel titleLabel1L, titleLabel2L, titleLabel3L, titleLabel4L, titleLabel5L, titleLabel6L;
    private JButton backBtn;
    private JTextField idF, nameF, roleF, securityF, passwordF;
    private Font font, font15, font20;

    public AdminSelfProfile() {
        font = new Font("Times New Roman", Font.BOLD, 25);
        font15 = new Font("Times New Roman", Font.BOLD, 15);
        font20 = new Font("Times New Roman", Font.BOLD, 20);

        this.setTitle("Admin Self Profile");
        this.setSize(660, 420);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

        mainP = new JPanel();
        mainP.setLayout(null);
        mainP.setBounds(0, 0, 660, 420);
        this.add(mainP);

        titleLabel1L = new JLabel("Self Profile");
        titleLabel1L.setBounds(260, 25, 300, 50);
        titleLabel1L.setFont(font);
        mainP.add(titleLabel1L);

        titleLabel2L = new JLabel("Id:");
        titleLabel2L.setBounds(200, 100, 70, 30);
        titleLabel2L.setFont(font15);
        mainP.add(titleLabel2L);

        idF = new JTextField("101");
        idF.setBounds(310, 100, 150, 30);
        idF.setBorder(BorderFactory.createLineBorder(null));
        idF.setFont(font20);
        idF.setEditable(false);
        mainP.add(idF);

        titleLabel3L = new JLabel("Name:");
        titleLabel3L.setBounds(200, 140, 50, 30);
        titleLabel3L.setFont(font15);
        mainP.add(titleLabel3L);

        nameF = new JTextField("khothik");
        nameF.setBounds(310, 140, 150, 30);
        nameF.setBorder(BorderFactory.createLineBorder(null));
        nameF.setFont(font20);
        nameF.setEditable(false);
        mainP.add(nameF);

        titleLabel4L = new JLabel("Role:");
        titleLabel4L.setBounds(200, 180, 80, 30);
        titleLabel4L.setFont(font15);
        mainP.add(titleLabel4L);

        roleF = new JTextField("1");
        roleF.setBounds(310, 180, 150, 30);
        roleF.setBorder(BorderFactory.createLineBorder(null));
        roleF.setFont(font20);
        roleF.setEditable(false);
        mainP.add(roleF);

        titleLabel5L = new JLabel("Security Ans:");
        titleLabel5L.setBounds(200, 220, 100, 30);
        titleLabel5L.setFont(font15);
        mainP.add(titleLabel5L);

        securityF = new JTextField("singing");
        securityF.setBounds(310, 220, 150, 30);
        securityF.setBorder(BorderFactory.createLineBorder(null));
        securityF.setFont(font20);
        securityF.setEditable(false);
        mainP.add(securityF);

        titleLabel6L = new JLabel("Password:");
        titleLabel6L.setBounds(200, 260, 80, 30);
        titleLabel6L.setFont(font15);
        mainP.add(titleLabel6L);

        passwordF = new JTextField("123");
        passwordF.setBounds(310, 260, 150, 30);
        passwordF.setBorder(BorderFactory.createLineBorder(null));
        passwordF.setFont(font20);
        passwordF.setEditable(false);
        mainP.add(passwordF);

        backBtn = new JButton("Back");
        backBtn.setBounds(275, 325, 90, 30);
        backBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                AdminPage ap = new AdminPage();
                setVisible(false);
                ap.setVisible(true);
            }
        });
        mainP.add(backBtn);
    }

    public static void main(String[] args) {
        new AdminSelfProfile();
    }
}
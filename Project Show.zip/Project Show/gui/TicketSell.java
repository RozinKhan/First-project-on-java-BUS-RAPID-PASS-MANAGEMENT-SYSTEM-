
package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class TicketSell extends JFrame implements ActionListener, MouseListener, ItemListener {

    JPanel panel;
    JLabel a1, a2, a3, x1, x2, fromLabel, toLabel, dateLabel, idLabel, nameLabel;
    JTextField idField, nameField;
    JButton ticket_pay, backBtn;
    JRadioButton rd1, rd2, aa, bb, cc, dd;
    ButtonGroup bt1, zz;
    JComboBox<String> busTime, ticket_no, fromBox, toBox, dateBox;
    Color color1;
    Font f0, f1, f2, f3, f4, f5;
    Cursor cursor;
    String selectedBus, selectedQuality, selectedTime, selectedFrom, selectedTo, selectedDate, selectedTicketNo;

    public TicketSell() {
        super("Bus ticket selling method");
        this.setSize(1100, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        panel = new JPanel();
        panel.setLayout(null);

        f0 = new Font("Britannic Bold", Font.BOLD + Font.ITALIC, 26);
        f1 = new Font("Monotype Corsiva", Font.BOLD + Font.ITALIC, 26);
        f2 = new Font("Monotype Corsiva", Font.BOLD, 22);
        f3 = new Font("Monotype Corsiva", Font.ITALIC, 18);
        f4 = new Font("Times New Roman", Font.BOLD, 22);
        f5 = new Font("Times New Roman", Font.BOLD, 18);
        color1 = new Color(0xffffff);
        cursor = new Cursor(Cursor.HAND_CURSOR);

        a1 = new JLabel("Select Bus");
        a1.setBounds(800, 80, 120, 25);
        a1.setFont(f4);
        a1.setForeground(Color.BLACK);
        panel.add(a1);

        aa = new JRadioButton("Ster Line");
        aa.setBounds(700, 120, 180, 40);
        aa.setCursor(cursor);
        aa.setContentAreaFilled(false);
        aa.setForeground(Color.BLACK);
        aa.addActionListener(this);
        panel.add(aa);

        bb = new JRadioButton("Shemoli");
        bb.setBounds(900, 120, 180, 40);
        bb.setCursor(cursor);
        bb.setContentAreaFilled(false);
        bb.setForeground(Color.BLACK);
        bb.addActionListener(this);
        panel.add(bb);

        cc = new JRadioButton("Relax");
        cc.setBounds(700, 200, 180, 60);
        cc.setCursor(cursor);
        cc.setContentAreaFilled(false);
        cc.setForeground(Color.BLACK);
        cc.addActionListener(this);
        panel.add(cc);

        dd = new JRadioButton("Dream Line");
        dd.setBounds(900, 200, 180, 60);
        dd.setCursor(cursor);
        dd.setContentAreaFilled(false);
        dd.setForeground(Color.BLACK);
        dd.addActionListener(this);
        panel.add(dd);

        zz = new ButtonGroup();
        zz.add(aa);
        zz.add(bb);
        zz.add(cc);
        zz.add(dd);

        x1 = new JLabel("(Regular TK. 350  /");
        x1.setBounds(530, 320, 300, 25);
        x1.setFont(f5);
        x1.setForeground(Color.BLACK);
        panel.add(x1);

        x2 = new JLabel("Premium TK. 400)");
        x2.setBounds(690, 320, 300, 25);
        x2.setFont(f5);
        x2.setForeground(Color.BLACK);
        panel.add(x2);

        rd1 = new JRadioButton("Regular");
        rd1.setBounds(230, 320, 100, 25);
        rd1.setFont(f4);
        rd1.setCursor(cursor);
        rd1.setContentAreaFilled(false);
        rd1.setForeground(Color.BLACK);
        rd1.addActionListener(this);
        panel.add(rd1);

        rd2 = new JRadioButton("Premium");
        rd2.setBounds(340, 320, 115, 25);
        rd2.setFont(f4);
        rd2.setCursor(cursor);
        rd2.setContentAreaFilled(false);
        rd2.setBorderPainted(false);
        rd2.setForeground(Color.BLACK);
        rd2.addActionListener(this);
        panel.add(rd2);

        bt1 = new ButtonGroup();
        bt1.add(rd1);
        bt1.add(rd2);

        a2 = new JLabel("Select Time");
        a2.setBounds(30, 400, 120, 25);
        a2.setFont(f4);
        a2.setForeground(Color.BLACK);
        panel.add(a2);

        String[] items = {" ", "11:00 AM", "01:00 PM", "03:15 PM", "04:00 PM", "04:20 PM", "04:45 PM", "05:00 PM", "05:30 PM", "06:00 PM", "07:15 PM", "08:00 PM", "08:10 PM"};
        busTime = new JComboBox<>(items);
        busTime.setBounds(30, 440, 170, 30);
        busTime.setFont(f5);
        busTime.addItemListener(this);
        panel.add(busTime);

        a3 = new JLabel("Number of Tickets");
        a3.setBounds(30, 510, 180, 25);
        a3.setFont(f4);
        a3.setForeground(Color.BLACK);
        panel.add(a3);

        String[] tic = {" ", "1", "2", "3", "4", "5", "6"};
        ticket_no = new JComboBox<>(tic);
        ticket_no.setBounds(30, 550, 170, 30);
        ticket_no.setFont(f4);
        ticket_no.addItemListener(this);
        panel.add(ticket_no);

        fromLabel = new JLabel("From");
        fromLabel.setBounds(310, 400, 120, 25);
        fromLabel.setFont(f4);
        fromLabel.setForeground(Color.BLACK);
        panel.add(fromLabel);

        String[] fromItems = {" ","Dhaka", "Feni", "Comilla", "Noakhali", "Laxmipur"};
        fromBox = new JComboBox<>(fromItems);
        fromBox.setBounds(310, 440, 170, 30);
        fromBox.setFont(f5);
        fromBox.addItemListener(this);
        panel.add(fromBox);

        toLabel = new JLabel("To");
        toLabel.setBounds(590, 400, 120, 25);
        toLabel.setFont(f4);
        toLabel.setForeground(Color.BLACK);
        panel.add(toLabel);

        String[] toItems = {" ","Feni", "Comilla", "Noakhali", "Laxmipur", "Dhaka"};
        toBox = new JComboBox<>(toItems);
        toBox.setBounds(590, 440, 170, 30);
        toBox.setFont(f5);
        toBox.addItemListener(this);
        panel.add(toBox);

        dateLabel = new JLabel("Date");
        dateLabel.setBounds(855, 400, 120, 25);
        dateLabel.setFont(f4);
        dateLabel.setForeground(Color.BLACK);
        panel.add(dateLabel);

        String[] dateItems = {" ","19-05-2024", "20-05-2024", "21-05-2024", "22-05-2024", "23-05-2024"};
        dateBox = new JComboBox<>(dateItems);
        dateBox.setBounds(855, 440, 170, 30);
        dateBox.setFont(f5);
        dateBox.addItemListener(this);
        panel.add(dateBox);

        idLabel = new JLabel("Id");
        idLabel.setBounds(30, 70, 120, 25);
        idLabel.setFont(f4);
        idLabel.setForeground(Color.BLACK);
        panel.add(idLabel);

        idField = new JTextField();
        idField.setBounds(30, 110, 200, 30);
        idField.setFont(f4);
        panel.add(idField);

        nameLabel = new JLabel("Name");
        nameLabel.setBounds(30, 200, 120, 25);
        nameLabel.setFont(f4);
        nameLabel.setForeground(Color.BLACK);
        panel.add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(30, 240, 200, 30);
        nameField.setFont(f4);
        panel.add(nameField);

        ticket_pay = new JButton("Proceed to Sell");
        ticket_pay.setBounds(440, 550, 200, 40);
        ticket_pay.setFont(f5);
        ticket_pay.addActionListener(this);
        panel.add(ticket_pay);

        backBtn = new JButton("Back");
        backBtn.setBounds(900, 550, 100, 30);
        backBtn.setFont(f2);
        backBtn.setCursor(cursor);
        backBtn.setBackground(color1);
        backBtn.setForeground(Color.BLACK);
        backBtn.setBorder(BorderFactory.createEmptyBorder());
        backBtn.addActionListener(this);
        panel.add(backBtn);

        this.add(panel);
        this.setVisible(true);
    }

    @Override
    public void mouseClicked(MouseEvent me) {
    }

    @Override
    public void mousePressed(MouseEvent me) {
    }

    @Override
    public void mouseReleased(MouseEvent me) {
    }

    @Override
    public void mouseEntered(MouseEvent me) {
    }

    @Override
    public void mouseExited(MouseEvent me) {
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == ticket_pay) {
            int i = 0, ans = 0;
            boolean x = false, y = false, z = false, w = false, d = false;

            if (selectedBus != null) {
                x = true;
            }
            if (selectedQuality != null) {
                if (selectedQuality.equals("Regular")) {
                    i = 350;
                } else if (selectedQuality.equals("Premium")) {
                    i = 400;
                }
            }
            if (selectedTime != null) {
                y = true;
            }
            if (selectedTicketNo != null) {
                z = true;
            }
            if (selectedFrom != null && selectedTo != null) {
                w = true;
            }
            if (selectedDate != null) {
                d = true;
            }

            if (x && y && z && w && d && (i == 350 || i == 400)) {
                int k = Integer.parseInt(selectedTicketNo);
                ans = i * k;
            }

            if (ans != 0) {
                String id = idField.getText();
                String name = nameField.getText();
                if (id.isEmpty() || name.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter both Id and Name", "!!!!!!", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    try (BufferedWriter bw = new BufferedWriter(new FileWriter("repository/data/employeeHowSells.txt", true))) {
                        bw.write(id + "," + name + "," + selectedBus + "," + selectedQuality + "," + selectedTime + "," + selectedFrom + "," + selectedTo + "," + selectedDate + "," + selectedTicketNo + "," + ans + "\n");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    int response = JOptionPane.showConfirmDialog(null, "Total ticket price is " + ans + " Tk", "Amount", JOptionPane.OK_CANCEL_OPTION);
                    if (response == JOptionPane.OK_OPTION) {
                        JOptionPane.showMessageDialog(null, "Your Sell is done", "Selling confirmation", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please Select all boxes", "!!!!!!", JOptionPane.INFORMATION_MESSAGE);
            }
        } else if (ae.getSource() == backBtn) {
            new EmployeePage(); 
            this.dispose();
        } else if (ae.getSource() == aa || ae.getSource() == bb || ae.getSource() == cc || ae.getSource() == dd) {
            if (aa.isSelected()) {
                selectedBus = "Ster Line";
            } else if (bb.isSelected()) {
                selectedBus = "Shemoli";
            } else if (cc.isSelected()) {
                selectedBus = "Relax";
            } else if (dd.isSelected()) {
                selectedBus = "Dream Line";
            }
            saveCurrentSelection();
        } else if (ae.getSource() == rd1 || ae.getSource() == rd2) {
            if (rd1.isSelected()) {
                selectedQuality = "Regular";
            } else if (rd2.isSelected()) {
                selectedQuality = "Premium";
            }
            saveCurrentSelection();
        }
    }

    @Override
    public void itemStateChanged(ItemEvent ie) {
        if (ie.getSource() == busTime) {
            selectedTime = (String) busTime.getSelectedItem();
        } else if (ie.getSource() == ticket_no) {
            selectedTicketNo = (String) ticket_no.getSelectedItem();
        } else if (ie.getSource() == fromBox) {
            selectedFrom = (String) fromBox.getSelectedItem();
        } else if (ie.getSource() == toBox) {
            selectedTo = (String) toBox.getSelectedItem();
        } else if (ie.getSource() == dateBox) {
            selectedDate = (String) dateBox.getSelectedItem();
        }
        saveCurrentSelection();
    }

    private void saveCurrentSelection() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("repository/data/currentSelection.txt"))) {
            bw.write((selectedBus != null ? selectedBus : "") + ",");
            bw.write((selectedTime != null ? selectedTime : "") + ",");
            bw.write((selectedQuality != null ? selectedQuality : "") + ",");
            bw.write((selectedFrom != null ? selectedFrom : "") + ",");
            bw.write((selectedTo != null ? selectedTo : "") + ",");
            bw.write((selectedDate != null ? selectedDate : "") + ",");
            bw.write((selectedTicketNo != null ? selectedTicketNo : "") + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new TicketSell();
    }
}
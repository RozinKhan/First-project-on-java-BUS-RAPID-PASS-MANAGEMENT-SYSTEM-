


package gui;
import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;

public class EmployeePage extends JFrame {
	private JPanel mainP;
	private JLabel titleLabel;
	private JButton customerDetailsBtn,EmployeeSelfProfileBtn,sellingDetailsBtn,ticketSellBtn,logOutBtn;
	private Font font;
	
	public EmployeePage(){
		font = new Font("Times New Roman",Font.BOLD,20);
		
		this.setTitle("Employee Page");
		this.setSize(660,550);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		
		mainP = new JPanel();
		mainP.setLayout(null);
		mainP.setBounds(0,0,660,550);
		this.add(mainP);
		
		titleLabel = new JLabel("Employee-Page");
		titleLabel.setBounds(270,50,150,30);
		titleLabel.setFont(font);
		mainP.add(titleLabel);
				
		
		customerDetailsBtn = new JButton("Customer Details");
		customerDetailsBtn.setBounds(120,120,150,50);
		mainP.add(customerDetailsBtn);
	
	    EmployeeSelfProfileBtn = new JButton("Self Profile");
		EmployeeSelfProfileBtn.setBounds(120,250,150,50);
		mainP.add(EmployeeSelfProfileBtn);
		
		sellingDetailsBtn = new JButton("Selling Details");
		sellingDetailsBtn.setBounds(380,120,150,50);
		mainP.add(sellingDetailsBtn);
		
		ticketSellBtn = new JButton("Tickets Sell");
		ticketSellBtn.setBounds(380,250,150,50);
		mainP.add(ticketSellBtn);
		
		logOutBtn = new JButton("Log-Out");
		logOutBtn.setBounds(250,380,150,50);
		mainP.add(logOutBtn);
		
		customerDetailsBtn.addActionListener(new ActionListener(){  
    public void actionPerformed(ActionEvent e){  
           CustomerDetails ac=new CustomerDetails();
		   dispose();
					ac.setVisible(true); 
    }  
    });  
	
		EmployeeSelfProfileBtn.addActionListener(new ActionListener(){  
    public void actionPerformed(ActionEvent e){  
           EmployeeSelfProfile sp=new EmployeeSelfProfile();
		   dispose();
					sp.setVisible(true); 
    }  
    });  
	
		sellingDetailsBtn.addActionListener(new ActionListener(){  
    public void actionPerformed(ActionEvent e){  
           SellingDetails td=new SellingDetails();
		   dispose();
					td.setVisible(true); 
    }  
    });  
	
		ticketSellBtn.addActionListener(new ActionListener(){  
    public void actionPerformed(ActionEvent e){  
           TicketSell ts=new TicketSell();
		   dispose();
					ts.setVisible(true); 
    }  
    });  
	
		logOutBtn.addActionListener(new ActionListener(){  
    public void actionPerformed(ActionEvent e){  
           Login lg=new Login();
		   dispose();
					lg.setVisible(true); 
    }  
    });  
	
	
	}
	
	

}
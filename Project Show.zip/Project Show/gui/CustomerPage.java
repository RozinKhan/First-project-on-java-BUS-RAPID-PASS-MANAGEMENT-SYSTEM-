


package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CustomerPage extends JFrame {
    private JPanel mainP;
    private JLabel titleLabel1L;
    private JButton TicketBuyBtn, CustomerSelfProfileBtn, logOutBtn;
    private Font font, font15, font20;

    public CustomerPage() {
        font = new Font("Times New Roman", Font.BOLD, 25);
        font15 = new Font("Times New Roman", Font.BOLD, 15);
        font20 = new Font("Times New Roman", Font.BOLD, 20);

        this.setTitle("Customer Page");
        this.setSize(660, 420);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        mainP = new JPanel();
        mainP.setLayout(null);
        mainP.setBounds(0, 0, 660, 420);
        this.add(mainP);

        titleLabel1L = new JLabel("Customer-Page");
        titleLabel1L.setBounds(245, 30, 300, 50);
        titleLabel1L.setFont(font);
        mainP.add(titleLabel1L);

        TicketBuyBtn = new JButton("Ticket-Buy");
        TicketBuyBtn.setBounds(150, 125, 150, 100);
        mainP.add(TicketBuyBtn);

        CustomerSelfProfileBtn = new JButton("Self-Profile");
        CustomerSelfProfileBtn.setBounds(330, 125, 150, 100);
        mainP.add(CustomerSelfProfileBtn);

        logOutBtn = new JButton("Log-Out");
        logOutBtn.setBounds(275, 250, 80, 30);
        mainP.add(logOutBtn);

        TicketBuyBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                BuyTicket ac = new BuyTicket();
                dispose();
                ac.setVisible(true);
            }
        });

        CustomerSelfProfileBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                CustomerSelfProfile ac = new CustomerSelfProfile();
                dispose();
                ac.setVisible(true);
            }
        });

        logOutBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Login loginFrame = new Login();
                dispose();
                loginFrame.setVisible(true);
            }
        });

        this.setVisible(true);
    }

    public static void main(String[] args) {
        new CustomerPage();
    }
}
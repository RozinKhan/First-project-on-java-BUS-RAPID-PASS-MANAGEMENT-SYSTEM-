

package gui;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import entities.*;
import repository.*;


public class ForgetPass extends JFrame implements ActionListener
{
	private JLabel userIdLabel, securityQuesLabel, securityAnsLabel, passLabel;
	private JTextField userF, securityAnsF;
	private JPasswordField passF;
	private JButton submitBtn, exitBtn, backBtn;
	private JPanel panel;
	
	public ForgetPass()
	{
		super("Forget Password Frame");
		this.setSize(700,400);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		this.panel=new JPanel();
		this.panel.setLayout(null);
		this.panel.setBounds(0,0,660,580);
		
		this.userIdLabel=new JLabel("User Id:");
		this.userIdLabel.setBounds(50,50,60,20);
		this.panel.add(userIdLabel);
		
		this.userF=new JTextField();
		this.userF.setBounds(120,45,100,30);
		this.panel.add(userF);
		
		this.securityQuesLabel=new JLabel("Security Ques: What is your pet name?:");
		this.securityQuesLabel.setBounds(50,90,300,20);
		this.panel.add(securityQuesLabel);
		
		this.securityAnsLabel=new JLabel("Security Ans:");
		this.securityAnsLabel.setBounds(50,120,100,20);
		this.panel.add(securityAnsLabel);
		
		this.securityAnsF=new JTextField();
		this.securityAnsF.setBounds(160,120,100,30);
		this.panel.add(securityAnsF);
		
		this.passLabel=new JLabel("new Password:");
		this.passLabel.setBounds(50,160,100,20);
		this.panel.add(passLabel);
		
		this.passF=new JPasswordField();
		this.passF.setBounds(160,160,100,30);
		this.panel.add(passF);
		
		this.submitBtn=new JButton("Submit");
		this.submitBtn.setBounds(50,200,100,30);
		this.submitBtn.addActionListener(this);
		this.panel.add(submitBtn);
		
		this.exitBtn=new JButton("Exit");
		this.exitBtn.setBounds(160,200,100,30);
		this.exitBtn.addActionListener(this);
		this.panel.add(exitBtn);
		
		this.backBtn=new JButton("Back");
		this.backBtn.setBounds(270,200,100,30);
		this.backBtn.addActionListener(this);
		this.panel.add(backBtn);
		
		
		this.add(panel);
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		String command= ae.getActionCommand();
		
		if(command.equals(submitBtn.getText()))
		{
			if((!userF.getText().isEmpty())&&(!passF.getText().isEmpty()))
			{
				String id, securityAns, newPass;
				id=userF.getText();
				securityAns=securityAnsF.getText();
				UserRepo urp=new UserRepo();
				User user=urp.searchById(id);
				if(user!=null)
				{
					if((user.getId().equals(id))&&(user.getSecurityAns().equals(securityAns)))
					{
						user.setPassword(passF.getText());
						urp.updateUser(user);
						JOptionPane.showMessageDialog(this,"Password changed successfully");
					}
					
					else
					{
						JOptionPane.showMessageDialog(this,"Wrong security Ans");
					}
				}
				
				else
				{
					JOptionPane.showMessageDialog(this,"User not Found");
				}
			}
			
			else
			{
				JOptionPane.showMessageDialog(this,"Fillup all the field");
			}
		}
		
		if(command.equals(backBtn.getText()))
		{
			Login lf=new Login();
			this.setVisible(false);
			lf.setVisible(true);
		}
		
		
		if(command.equals(exitBtn.getText()))
		{
			System.exit(0);
		}
	}
	
}

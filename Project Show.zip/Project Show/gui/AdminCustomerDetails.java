


package gui;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class AdminCustomerDetails extends JFrame {
    private JPanel mainP, mainQ, mainR, mainS, mainT;
    private JLabel titleLabel1L, titleLabel2L, titleLabel3L, titleLabel4L, titleLabel5L, titleLabel6L, titleLabel7L, titleLabel8L;
    private JButton updateBtn, addBtn, removeBtn, backBtn;
    private JTextField idF, numberF, fromF, toF, countTicketF, busNameF, passwordF;
    private JTable table;
    private JScrollPane scroll;
    private DefaultTableModel model;
    private Font font, font15, font20;

    public AdminCustomerDetails() {
        font = new Font("Times New Roman", Font.BOLD, 25);
        font15 = new Font("Times New Roman", Font.BOLD, 15);
        font20 = new Font("Times New Roman", Font.BOLD, 20);

        this.setTitle("Customer Details");
        this.setSize(1000, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);

        mainP = new JPanel();
        mainP.setLayout(null);
        mainP.setBounds(0, 0, 1000, 700);
        this.add(mainP);

        mainQ = new JPanel();
        mainQ.setLayout(null);
        mainQ.setBounds(0, 0, 1000, 50);
        mainP.add(mainQ);

        mainR = new JPanel();
        mainR.setLayout(null);
        mainR.setBounds(0, 50, 350, 550);
        mainP.add(mainR);

        mainS = new JPanel();
        mainS.setLayout(null);
        mainS.setBounds(350, 50, 650, 550);
        mainP.add(mainS);

        model = new DefaultTableModel();
        String[] cols = {"Id", "Number", "From", "To", "T-count", "B-Name", "pass"};
        model.setColumnIdentifiers(cols);

    
        loadTableData();

        table = new JTable(model);
        table.setFont(font15);
        table.setRowHeight(30);
        scroll = new JScrollPane(table);
        scroll.setBounds(0, 50, 620, 480);
        mainS.add(scroll);

        mainT = new JPanel();
        mainT.setLayout(null);
        mainT.setBounds(0, 600, 1000, 100);
        mainP.add(mainT);

        titleLabel1L = new JLabel("Customer Details");
        titleLabel1L.setBounds(415, 0, 200, 50);
        titleLabel1L.setFont(font);
        mainQ.add(titleLabel1L);

        titleLabel2L = new JLabel("Id:");
        titleLabel2L.setBounds(50, 100, 30, 30);
        titleLabel2L.setFont(font15);
        mainR.add(titleLabel2L);

        idF = new JTextField();
        idF.setBounds(90, 100, 150, 30);
        idF.setBorder(BorderFactory.createLineBorder(null));
        idF.setFont(font20);
        mainR.add(idF);

        titleLabel3L = new JLabel("Number:");
        titleLabel3L.setBounds(50, 150, 70, 30);
        titleLabel3L.setFont(font15);
        mainR.add(titleLabel3L);

        numberF = new JTextField();
        numberF.setBounds(130, 150, 150, 30);
        numberF.setBorder(BorderFactory.createLineBorder(null));
        numberF.setFont(font20);
        mainR.add(numberF);

        titleLabel4L = new JLabel("From:");
        titleLabel4L.setBounds(50, 200, 50, 30);
        titleLabel4L.setFont(font15);
        mainR.add(titleLabel4L);

        fromF = new JTextField();
        fromF.setBounds(110, 200, 150, 30);
        fromF.setBorder(BorderFactory.createLineBorder(null));
        fromF.setFont(font20);
        mainR.add(fromF);

        titleLabel5L = new JLabel("To:");
        titleLabel5L.setBounds(50, 250, 30, 30);
        titleLabel5L.setFont(font15);
        mainR.add(titleLabel5L);

        toF = new JTextField();
        toF.setBounds(90, 250, 150, 30);
        toF.setBorder(BorderFactory.createLineBorder(null));
        toF.setFont(font20);
        mainR.add(toF);

        titleLabel6L = new JLabel("Count Ticket:");
        titleLabel6L.setBounds(50, 300, 100, 30);
        titleLabel6L.setFont(font15);
        mainR.add(titleLabel6L);

        countTicketF = new JTextField();
        countTicketF.setBounds(160, 300, 150, 30);
        countTicketF.setBorder(BorderFactory.createLineBorder(null));
        countTicketF.setFont(font20);
        mainR.add(countTicketF);

        titleLabel7L = new JLabel("Bus Name:");
        titleLabel7L.setBounds(50, 350, 80, 30);
        titleLabel7L.setFont(font15);
        mainR.add(titleLabel7L);

        busNameF = new JTextField();
        busNameF.setBounds(140, 350, 150, 30);
        busNameF.setBorder(BorderFactory.createLineBorder(null));
        busNameF.setFont(font20);
        mainR.add(busNameF);

        titleLabel8L = new JLabel("Password:");
        titleLabel8L.setBounds(50, 400, 80, 30);
        titleLabel8L.setFont(font15);
        mainR.add(titleLabel8L);

        passwordF = new JTextField();
        passwordF.setBounds(140, 400, 150, 30);
        passwordF.setBorder(BorderFactory.createLineBorder(null));
        passwordF.setFont(font20);
        mainR.add(passwordF);

        updateBtn = new JButton("Update");
        updateBtn.setBounds(170, 0, 150, 50);
        mainT.add(updateBtn);

        addBtn = new JButton("Add");
        addBtn.setBounds(330, 0, 150, 50);
        mainT.add(addBtn);

        removeBtn = new JButton("Remove");
        removeBtn.setBounds(490, 0, 150, 50);
        mainT.add(removeBtn);

        backBtn = new JButton("Back");
        backBtn.setBounds(650, 0, 150, 50);
        mainT.add(backBtn);
		


        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addCustomer();
            }
        });

        removeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeCustomer();
            }
        });

        updateBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateCustomer();
            }
        });

        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                backToAdminHomePage();
            }
			
        });
		
		 
		
		 
    }




    private void loadTableData() {
        try (BufferedReader br = new BufferedReader(new FileReader("repository/data/customerDetails.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                model.addRow(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveTableData() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("repository/data/customerDetails.txt"))) {
            for (int i = 0; i < model.getRowCount(); i++) {
                for (int j = 0; j < model.getColumnCount(); j++) {
                    bw.write(model.getValueAt(i, j).toString());
                    if (j < model.getColumnCount() - 1) bw.write(",");
                }
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void addCustomer() {
        String[] data = {
            idF.getText(), numberF.getText(), fromF.getText(), toF.getText(),
            countTicketF.getText(), busNameF.getText(), passwordF.getText()
        };
        model.addRow(data);
        saveTableData();
        clearFields();
    }

    private void removeCustomer() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            model.removeRow(selectedRow);
            saveTableData();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to remove.");
        }
    }

    private void updateCustomer() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            model.setValueAt(idF.getText(), selectedRow, 0);
            model.setValueAt(numberF.getText(), selectedRow, 1);
            model.setValueAt(fromF.getText(), selectedRow, 2);
            model.setValueAt(toF.getText(), selectedRow, 3);
            model.setValueAt(countTicketF.getText(), selectedRow, 4);
            model.setValueAt(busNameF.getText(), selectedRow, 5);
            model.setValueAt(passwordF.getText(), selectedRow, 6);
            saveTableData();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to update.");
        }
    }

    private void clearFields() {
        idF.setText("");
        numberF.setText("");
        fromF.setText("");
        toF.setText("");
        countTicketF.setText("");
        busNameF.setText("");
        passwordF.setText("");
    }

   private void backToAdminHomePage() {
        new AdminPage();
        this.dispose();
    }
	

	
	

    public static void main(String[] args) {
        new CustomerDetails();
    }
}
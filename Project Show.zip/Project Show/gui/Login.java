


package gui;
import entities.*;
import interfaces.*;
import repository.*;

import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.lang.*;
import java.awt.event.*;

public class Login extends JFrame implements ActionListener {
	private JPanel mainP, loginSide;
	private JLabel userL, passL, logo, showhideL, forgetL, showloginL;
	private JTextField userF;
	private JPasswordField passF;
	private JButton loginB, registerB, forgetPassBtn;
	private ImageIcon icon, icon1;
	private Image show, hide;
	private Font font14;

	public Login() {
		icon = new ImageIcon("icon/show.png");
		show = icon.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
		
		icon1 = new ImageIcon("icon/hide.png");
		hide = icon1.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
		
		font14 = new Font("Times New Roman", Font.BOLD, 14);
		
		this.setSize(660, 420);
		this.setTitle(" this Login Page -Rapid PASS BusManagement System");
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		mainP = new JPanel();
		mainP.setLayout(null);
		mainP.setBackground(Color.gray);
		mainP.setBounds(0, 0, 660, 580);
		
		showloginL = new JLabel("Login-Page");
		showloginL.setBounds(290, 100, 80, 30);
		showloginL.setFont(font14);
		mainP.add(showloginL);
		
		loginSide = new JPanel();
		loginSide.setLayout(null);
		loginSide.setBounds(0, 0, 660, 580);
		mainP.add(loginSide);
		
		userL = new JLabel("UserName: ");
		userL.setBounds(230, 150, 80, 30);
		userL.setFont(font14);
		loginSide.add(userL);
		
		userF = new JTextField();
		userF.setBounds(320, 150, 120, 30);
		userF.setBorder(BorderFactory.createLineBorder(null));
		userF.setFont(font14);
		loginSide.add(userF);
		
		passL = new JLabel("Password: ");
		passL.setBounds(230, 190, 80, 30);
		passL.setFont(font14);
		loginSide.add(passL);
		
		passF = new JPasswordField();
		passF.setBounds(320, 190, 120, 30);
		passF.setBorder(BorderFactory.createLineBorder(null));
		passF.setFont(font14);
		loginSide.add(passF);
		
		showhideL = new JLabel();
		showhideL.setLayout(null);
		showhideL.setBounds(235, 190, 30, 30);
		showhideL.setIcon(new ImageIcon(hide));
		loginSide.add(showhideL);
		
		registerB = new JButton("Register");
		registerB.setBounds(210, 240, 115, 40);
		registerB.setBackground(new Color(0x358790));
		registerB.setForeground(Color.white);
		registerB.setFont(font14);
		registerB.setBorder(BorderFactory.createLineBorder(null));
		loginSide.add(registerB);
		
		loginB = new JButton("Login");
		loginB.setBounds(335, 240, 115, 40);
		loginB.setBackground(new Color(0x358790));
		loginB.setForeground(Color.white);
		loginB.setFont(font14);
		loginB.setBorder(BorderFactory.createLineBorder(null));
		loginSide.add(loginB);

		forgetPassBtn = new JButton("Forget Pass");
		forgetPassBtn.setBounds(270, 290, 120, 30);
		forgetPassBtn.addActionListener(this);
		loginSide.add(forgetPassBtn);
		
		registerB.addActionListener(this);
		loginB.addActionListener(this);
		this.add(mainP);
		this.setVisible(true);
	}
	
	public void actionPerformed(ActionEvent ae) {
		String command = ae.getActionCommand();
		
		if (command.equals(loginB.getText())) {
			try {
				String uId = userF.getText();
				String pass = new String(passF.getPassword());

				if (uId.isEmpty() || pass.isEmpty()) {
					throw new Exception("Please fill up the box");
				}

				UserRepo urp = new UserRepo();
				User user = urp.searchById(uId);
				
				if (user != null) {
					if (user.getId().equals(uId) && user.getPassword().equals(pass) && user.getRole() == 1) {
						AdminPage ahf = new AdminPage();
						this.setVisible(false);
						ahf.setVisible(true);
					} else if (user.getId().equals(uId) && user.getPassword().equals(pass) && user.getRole() == 2) {
						EmployeePage ahf = new EmployeePage();
						this.setVisible(false);
						ahf.setVisible(true);
					} else if (user.getId().equals(uId) && user.getPassword().equals(pass) && user.getRole() == 3) {
						CustomerPage ahf = new CustomerPage();
						this.setVisible(false);
						ahf.setVisible(true);
					} else {
						JOptionPane.showMessageDialog(this, "Wrong user Id or Password!");
					}
				} else {
					JOptionPane.showMessageDialog(this, "Wrong user Id or Password!");
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(this, e.getMessage());
			}
		}
		
		if (command.equals(registerB.getText())) {
			Register r = new Register();
			this.setVisible(false);
			r.setVisible(true);
		}
		if (command.equals(forgetPassBtn.getText())) {
			ForgetPass fpf = new ForgetPass();
			this.setVisible(false);
			fpf.setVisible(true);
		}
	}
}
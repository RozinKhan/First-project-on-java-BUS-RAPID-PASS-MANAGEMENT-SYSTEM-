


package gui;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class AdminSellingDetails extends JFrame {
    private JPanel mainP;
    private JLabel titleLabel;
    private JButton backBtn;
    private JTable table;
    private JScrollPane scroll;
    private DefaultTableModel model;
    private Font font, font15;

    public AdminSellingDetails() {
        font = new Font("Times New Roman", Font.BOLD, 25);
        font15 = new Font("Times New Roman", Font.BOLD, 15);

        this.setTitle("Selling Details");
        this.setSize(1000, 700);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setLayout(null);

        mainP = new JPanel();
        mainP.setLayout(null);
        mainP.setBounds(0, 0, 1000, 700);
        this.add(mainP);

        titleLabel = new JLabel("Selling Details");
        titleLabel.setBounds(400, 0, 200, 50);
        titleLabel.setFont(font);
        mainP.add(titleLabel);

        backBtn = new JButton("Back");
        backBtn.setBounds(850, 10, 100, 30);
        mainP.add(backBtn);

        model = new DefaultTableModel();
        String[] cols = {"Bus", "Quality", "Time", "From", "To", "Date", "Number of Tickets", "Payment"};
        model.setColumnIdentifiers(cols);

        loadTableData();

        table = new JTable(model);
        table.setFont(font15);
        table.setRowHeight(30);
        scroll = new JScrollPane(table);
        scroll.setBounds(50, 100, 900, 500);
        mainP.add(scroll);

        backBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                backToAdminPage();
            }
        });

        this.setVisible(true);
    }

    private void loadTableData() {
        try (BufferedReader br = new BufferedReader(new FileReader("repository/data/sellingDetails.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                model.addRow(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void backToAdminPage() {
        new AdminPage();
        this.dispose();
    }

    public static void main(String[] args) {
        new AdminSellingDetails();
    }
}
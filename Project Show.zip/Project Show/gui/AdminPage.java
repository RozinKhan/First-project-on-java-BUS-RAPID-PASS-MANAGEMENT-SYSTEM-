


package gui;
import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;

public class AdminPage extends JFrame{ 
	private JPanel mainP;
	private JLabel titleLabel;
	private JButton employeeDetailsBtn,customerDetailsBtn,sellingDetailsBtn,AdminSelfProfileBtn,logoutBtn;
	private Font font;
	
	public AdminPage(){
		font = new Font("Times New Roman",Font.BOLD,20);
		
		this.setTitle("Admin Page");
		this.setSize(660,550);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		
		
		mainP = new JPanel();
		mainP.setLayout(null);
		mainP.setBounds(0,0,660,550);
		this.add(mainP);
		
		titleLabel = new JLabel("Admin-Page");
		titleLabel.setBounds(270,50,150,30);
		titleLabel.setFont(font);
		mainP.add(titleLabel);
				
		
		employeeDetailsBtn = new JButton("Employee Details");
		employeeDetailsBtn.setBounds(120,120,150,50);
		mainP.add(employeeDetailsBtn);
	
	    customerDetailsBtn = new JButton("Customer Details");
		customerDetailsBtn.setBounds(120,250,150,50);
		mainP.add(customerDetailsBtn);
		
		sellingDetailsBtn = new JButton("Selling Details");
		sellingDetailsBtn.setBounds(380,120,150,50);
		mainP.add(sellingDetailsBtn);
		
		AdminSelfProfileBtn = new JButton("Self Profile");
		AdminSelfProfileBtn.setBounds(380,250,150,50);
		mainP.add(AdminSelfProfileBtn);
		
		logoutBtn = new JButton("Log Out");
		logoutBtn.setBounds(250,380,150,50);
		mainP.add(logoutBtn);

		
		
		
		
			employeeDetailsBtn.addActionListener(new ActionListener(){  
    public void actionPerformed(ActionEvent e){  
           EmployeeDetails ed=new EmployeeDetails();
		   dispose();
					ed.setVisible(true); 
    }  
    });  
	
		customerDetailsBtn.addActionListener(new ActionListener(){  
    public void actionPerformed(ActionEvent e){  
           AdminCustomerDetails ad=new AdminCustomerDetails();
		   dispose();
					ad.setVisible(true); 
    }  
    });  
	
		sellingDetailsBtn.addActionListener(new ActionListener(){  
    public void actionPerformed(ActionEvent e){  
           AdminSellingDetails td=new AdminSellingDetails();
		   dispose();
					td.setVisible(true); 
    }  
    });  
	
		AdminSelfProfileBtn.addActionListener(new ActionListener(){  
    public void actionPerformed(ActionEvent e){  
           AdminSelfProfile sp=new AdminSelfProfile();
		   dispose();
					sp.setVisible(true); 
    }  
    });

    
		logoutBtn.addActionListener(new ActionListener(){  
    public void actionPerformed(ActionEvent e){ 
    	Login l=new Login();
		   dispose();
					l.setVisible(true);

          
    }  
    }); 
    
		
	}
	public static void main(String[] args){
		new AdminPage();
	}
}
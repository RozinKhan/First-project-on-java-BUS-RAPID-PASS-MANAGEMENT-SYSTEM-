
package interfaces;
import java.lang.*;
import java.util.*;
 
public interface IEmployeeRepo{

	void addEmployee(Employee u);

	void removeEmployee(Employee u);

	void updateEmployee(Employee u);

	Employee searchById(int id);

	Employee [] allEmployee();

}
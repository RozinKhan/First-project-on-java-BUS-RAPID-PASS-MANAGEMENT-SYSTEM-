
package interfaces;
import java.lang.*;
import java.util.*;
 
public interface ICustomerRepo{

	void addCustomer(Customer u);

	void removeCustomer(Customer u);

	void updateCustomer(Customer u);

	Customer searchById(int id);

	Customer [] allCustomer();

}

package interfaces;
import java.lang.*;
import java.util.*;
 
public interface IPaymentRepo{

	void addPayment(Payment u);

	void removePayment(Payment u);

	void updatePayment(Payment u);

	Payment searchById(int id);

	Payment [] allPayment();

}
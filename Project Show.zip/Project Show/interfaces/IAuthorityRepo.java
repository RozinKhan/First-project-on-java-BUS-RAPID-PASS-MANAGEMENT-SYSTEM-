
package interfaces;
import java.lang.*;
import java.util.*;
 
public interface IAuthorityRepo{

	void addAuthority(Authority u);

	void removeAuthority(Authority u);

	void updateAuthority(Authority u);

	Authority searchById(int id);

	Authority [] allAuthority();

}
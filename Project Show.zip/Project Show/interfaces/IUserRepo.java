package interfaces;
import entities.*;
import java.lang.*;
 
public interface IUserRepo{

	void addUser(User u);

	void removeUser(String b);

	void updateUser(User u);

	User searchById(String id);

	User[] allUser();

}
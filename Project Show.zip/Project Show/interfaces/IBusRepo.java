
package interfaces;
import java.lang.*;
import java.util.*;
 
public interface IBusRepo{

	void addBus(Bus u);

	void removeBus(Bus u);

	void updateBus(Bus u);

	Bus searchById(int id);

	Bus [] allBus();

}
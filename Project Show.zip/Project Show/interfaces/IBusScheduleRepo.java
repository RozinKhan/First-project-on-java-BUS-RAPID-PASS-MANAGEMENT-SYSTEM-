
package interfaces;
import java.lang.*;
import java.util.*;
 
public interface IBusScheduleRepo{

	void addBusSchedule(BusSchedule u);

	void removeBusSchedule(BusSchedule u);

	void updateBusSchedule(BusSchedule u);

	BusSchedule searchById(int id);

	BusSchedule [] allBusSchedule();

}
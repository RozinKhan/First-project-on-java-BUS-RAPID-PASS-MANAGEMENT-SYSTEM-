import java.lang.*;

public class Customer extends User
{
	private String membershipType;
	
	public ()
	{
	}
	
	public Customer(String id, String name, int phoneNo, String address, int role, String securityAns, String password, String membershipType)
	{
		super(id, name, phoneNo, address, role, securityAns, password);
		this.membershipType=membershipType;
	}
	
	public void setMembershipType(String membershipType)
	{
		this.membershipType=membershipType;
	}
	public String getMembershipType()
	{
		return this.membershipType;
	}
	
	
	
	
	
	public String toStringCustomer(){

		String str = this.CustomerId+","this.name+","+this.role+","+this.securityAns+","+this.password+","+this.membershipType+"\n";

		return str;

	}

	public Customer fromCustomer(String str){

		String data[] = str.split(",");

		Customer u= new Customer();

		u.setId(data[0]);

		u.setName(data[1]);

		u.setRole(data[2]);

		u.setSecurityAns(data[3]);

		u.setPassword(data[4]);
		
		u.setmembershipType(data[5]);


		return u;

	}
}
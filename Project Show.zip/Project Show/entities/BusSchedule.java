import java.lang.*;

public class BusSchedule
{
	private String busScheduled,fromlocation,tolocation,date,duratiion;
	Bus busid;

	
	
	public BusSchedule()
	{
		
	}
	
	public BusSchedule(String busScheduled,String fromlocation,String tolocation , String date,String duratiion,Bus busid)
	{
		this.busScheduled=busScheduled;
		this.fromlocation=fromlocation;
		this.tolocation=tolocation;
		this.date=date;
		this.duratiion=duratiion;
		this.busid=busid;
		

	}
	
	public void setbusScheduled(String busScheduled)
	{
		this.busScheduled=busScheduled;
	}
	public void setfromlocation(String fromlocation)
	{
		this.fromlocation=fromlocation;
	}
	
	public void settolocation(String tolocation)
	{
		this.tolocation=tolocation;
	}
	public void setdate(String date)
	{
		this.date=date;
	}
	public void setduratiion(String duratiion)
	{
		this.duratiion=duratiion;
	}

	


	
	
	public String getbusScheduled()
	{
		return this.busScheduled;
	}
	public String getfromlocation()
	{
		return this.fromlocation;
	}
	public String gettolocation()
	{
		return this.tolocation;
	}
	
	public String getdate()
	{
		return this.date;
		
		
	}
	public String getduratiion()
	{
		return this.duratiion;
		
		
	}
	
	
	public String toStringUser(){

		String str = this.busScheduled+","this.fromlocation+","+this.tolocation+","+this.date+","+this.duratiion+","+busid.getbusid()+"\n";

		return str;

	}

	public BusSchedule fromBusSchedule(String str){

		String data[] = str.split(",");

		BusSchedule u= new BusSchedule();

		

		u.setbusScheduled(data[0]);

		u.setfromlocation(data[1]);

		u.settolocation(data[2]);

		u.setdate(data[3]);
		u.setduratiion(data[4]);
		busid.setbusid(data[5]);
		
		
		return u;

	}
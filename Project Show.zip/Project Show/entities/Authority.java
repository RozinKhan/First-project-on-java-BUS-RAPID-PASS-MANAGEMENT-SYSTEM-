import java.lang.*;

public class Authority extends User
{
	private String type;
	
	public ()
	{
	}
	
	public Authority(String id, String name, int phoneNo, String address, int role, String securityAns, String password, String type)
	{
		super(id, name, phoneNo, address, role, securityAns, password);
		this.type=type;
	}
	
	public void setType(String type)
	{
		this.type=type;
	}
	public String getType()
	{
		return this.type;
	}
	
	
	
	
	
	public String toStringAuthority(){

		String str = this.AuthorityId+","this.name+","+this.role+","+this.securityAns+","+this.password+","+this.type+"\n";

		return str;

	}

	public Authority fromAuthority(String str){

		String data[] = str.split(",");

		Authority u= new Authority();

		u.setId(data[0]);

		u.setName(data[1]);

		u.setRole(data[2]);

		u.setSecurityAns(data[3]);

		u.setPassword(data[4]);
		
		u.setType(data[5]);


		return u;

	}
}
package entities;
import java.lang.*;

public class User
{
	protected String id, name, address, securityAns, password;
    protected int phoneNo, role;
	
	
	public User()
	{
	}
	
	public User(String id, String name, int phoneNo, String address, int role, String securityAns, String password)
	{
		this.id=id;
		this.name=name;
		this.phoneNo=phoneNo;
        this.address=address;
        this.role=role;
        this.securityAns=securityAns;
        this.password=password;

	}
	
	public void setId(String id)
	{
		this.id=id;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	public void setPhoneNo(int phoneNo)
	{
		this.phoneNo=phoneNo;
	}
	public void setAddress(String address)
	{
        this.address=address;
	}
	public void setRole(int role)
	{
		this.role=role;
	}
	public void setSecurityAns(String securityAns)
	{
        this.securityAns=securityAns;
	}
	public void setPassword(String password)
	{
        this.password=password;
	}
	
	
	
	public String getId()
	{
		return this.id;
	}
	public String getName()
	{
		return this.name;
	}
	public int getPhoneNo()
	{
		return this.phoneNo;
	}
	public String getAddress()
	{
		return this.address;
	}
	public int getRole()
	{
		return this.role;
	}
	public String getSecurityAns()
	{
		return this.securityAns;
	}
	public String getPassword()
	{
		return this.password;
	}
	
	
	
public String toStringUser(){

		String str = this.id+","+this.name+","+this.role+","+this.securityAns+","+this.password+"\n";

		return str;

	}

	public User fromUser(String str){

		String data[] = str.split(",");

		User u= new User();

		u.setId(data[0]);

		u.setName(data[1]);

		u.setRole(Integer.parseInt(data[2]));

		u.setSecurityAns(data[3]);

		u.setPassword(data[4]);

		return u;

	}
	
}
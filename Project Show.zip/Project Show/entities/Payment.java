import java.lang.*;

public class Payment
{
	private String paymentid,date;
	private int amount;
	Ticket ticketid;
	User userId;

	
	
	public Payment()
	{
		
	}
	
	public Payment(String paymentid,String date,int amount ,Ticket ticketid,User userId )
	{
		this.paymentid=paymentid;
		this.date=date;
		this.amount=amount;
		this.ticketid=ticketid;
		this.userId=userId;
		
		

	}
	
	public void setpaymentid(String paymentid)
	{
		this.paymentid=paymentid;
	}
	public void setdate(String date)
	{
		this.date=date;
	}
	
	public void setamount(int amount)
	{
		this.amount=amount;
	}

	


	
	
	public String getpaymentid()
	{
		return this.paymentid;
	}
	public String getdate()
	{
		return this.date;
	}
	public int getamount()
	{
		return this.amount;
	}

	
	
		
	
	
	public String toStringUser(){

		String str = this.paymentid+","this.date+","+this.amount+","+ticketid.getticketid()+","+userId.getuserId()+",+\n";

		return str;

	}

	public User fromUser(String str){

		String data[] = str.split(",");

		User u= new User();

		

		u.setpaymentid(data[0]);

		u.setdate(data[1]);

		u.setamount(data[2]);
		ticketid.setticketid(data[3]);
		userId.setuserId(data[4]);



		
		return u;

	}
import java.lang.*;

public class Bus
{
	private String busid,name,category;
	private int totalseat,priceperseat,availableseat,bookedseat;
	
	
	public Bus()
	{
	

	}
	
	public Bus(String busid,String name,String category , int totalseat,int priceperseat,int availableseat,int bookedseat)
	{
		this.busid=busid;
		this.name=name;
		this.category=category;
		this.totalseat=totalseat;
		this.priceperseat=priceperseat;
		this.availableseat=availableseat;
		this.bookedseat=bookedseat;

	}
	
	public void setbusid(String busid)
	{
		this.busid=busid;
	}
	public void setname(String name)
	{
		this.name=name;
	}
	
	public void setcategory(String category)
	{
		this.category=category;
	}
	public void settotalseat(int totalseat)
	{
		this.totalseat=totalseat;
	}
	public void setpriceperseat(int priceperseat)
	{
		this.priceperseat=priceperseat;
	}
	public void setavailableseat(int availableseat)
	{
		this.availableseat=availableseat;
	}
	public void setpriceperseat(int priceperseat)
	{
		this.bookedseat=bookedseat;
	}


	
	
	public String getbusid()
	{
		return this.busid;
	}
	public String getname()
	{
		return this.name;
	}
	public String getcategory()
	{
		return this.category;
	}
	
	public int gettotalseat()
	{
		return this.totalseat;
		
		
	}
	public int getpriceperseat()
	{
		return this.priceperseat;
		
		
	}
	public int getavailableseat()
	{
		return this.availableseat;
		
		
	}
	public int getbookedseat()
	{
		return this.bookedseat;
		
		
	}
	
	public String toStringUser(){

		String str = this.busid+","this.name+","+this.category+","+this.totalseat+","+this.priceperseat+","+this.availableseat+","+this.bookedseat+"\n";

		return str;

	}

	public Bus fromBus(String str){

		String data[] = str.split(",");

		Bus u= new Bus();

		u.setbusid(data[0]);

		u.setname(data[1]);

		u.setcategory(data[2]);

		u.settotalseat(data[3]);

		u.setpriceperseat(data[4]);
		u.setavailableseat(data[5]);
		u.setbookedseat(data[6]);
		
		return u;

	}
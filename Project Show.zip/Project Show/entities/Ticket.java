import java.lang.*;

public class Ticket
{
	private String ticketid,numberofTicket,totalamount,paidAmount,dueAmount;
	Bus busid;
	BusSchedule busScheduled;
	User userId;

	
	
	public Ticket()
	{
		
	}
	
	public Ticket(String ticketid,String numberofTicket,int totalamount ,int paidAmount,int dueAmount, Bus busid,BusSchedule busScheduled,User userId)
	{
		this.ticketid=ticketid;
		this.numberofTicket=numberofTicket;
		this.totalamount=totalamount;
		this.paidAmount=paidAmount;
		this.dueAmount=dueAmount;
		this.busid=busid;
		this.busScheduled=busScheduled;
		this.userId=userId;
		
		

	}
	
	public void setticketid(String ticketid)
	{
		this.ticketid=ticketid;
	}
	public void setnumberofTicket(String numberofTicket)
	{
		this.numberofTicket=numberofTicket;
	}
	
	public void settotalamount(int totalamount)
	{
		this.totalamount=totalamount;
	}
	public void setpaidAmount(int paidAmount)
	{
		this.paidAmount=paidAmount;
	}
	public void setdueAmount(int dueAmount)
	{
		this.dueAmount=dueAmount;
	}

	
	


	
	
	public String getticketid()
	{
		return this.ticketid;
	}
	public String getnumberofTicket()
	{
		return this.numberofTicket;
	}
	public int gettotalamount()
	{
		return this.totalamount;
	}
	public String getpaidAmount()
	{
		return this.paidAmount;
	}
	public String getdueAmount()
	{
		return this.dueAmount;
	}
	
	
	
	
	public String toStringUser(){

		String str = this.ticketid+","this.numberofTicket+","+this.totalamount+","+this.paidAmount+","+this.dueAmount+","+busid.getbusid()+","+busScheduled.getbusScheduled()+","+userId.getuserId()+"\n"

		return str;

	}

	public User fromUser(String str){

		String data[] = str.split(",");

		User u= new User();

		

		u.setticketid(data[0]);

		u.setnumberofTicket(data[1]);

		u.settotalamount(data[2]);
		u.setpaidAmount(data[3]);
		u.setdueAmount(data[4]);




		busid.setbusid(data[5]);
		busScheduled.setbusScheduled(data[6]);
		userId.setuserId(data[7]);
		
		
		return u;

	}
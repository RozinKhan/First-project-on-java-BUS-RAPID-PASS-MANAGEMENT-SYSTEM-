import java.lang.*;

public class Employee extends User
{
	private int salary;
	
	public ()
	{
	}
	
	public Employee(String id, String name, int phoneNo, String address, int role, String securityAns, String password, int salary)
	{
		super(id, name, phoneNo, address, role, securityAns, password);
		this.salary=salary;
	}
	
	public void setSalary(int salary)
	{
		this.salary=salary;
	}
	public int getsalary()
	{
		return this.salary;
	}
	
	
	
	
	
	public int tointEmployee(){

		int str = this.EmployeeId+","this.name+","+this.role+","+this.securityAns+","+this.password+","+this.salary+"\n";

		return str;

	}

	public Employee fromEmployee(int str){

		int data[] = str.split(",");

		Employee u= new Employee();

		u.setId(data[0]);

		u.setName(data[1]);

		u.setRole(data[2]);

		u.setSecurityAns(data[3]);

		u.setPassword(data[4]);
		
		u.setsalary(data[5]);


		return u;

	}
}
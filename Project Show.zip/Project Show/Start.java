import java.lang.*;
import gui.*;
import repository.*;
import entities.*;
import interfaces.*;

public class Start{
	public static void main(String[] args)
	{new Login();}
}
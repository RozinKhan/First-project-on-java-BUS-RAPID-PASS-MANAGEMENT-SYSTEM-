package repository;
import java.lang.*;
import entities.*;
import interfaces.*;
 
public class AuthorityRepo{
	public void addAuthority(Authority u){
		Authority[] list = this.allAuthority();
		for(int i=0; i<list.length; i++){
			if(list[i]==null){
				list[i]=u;
				break;
			}
		}
		this.write(list);
	}
	public void removeAuthority(String key){
		Authority[] list = this.allAuthority();
		for(int i=0; i<list.length; i++){
			if(list[i]!=null){
				if(list[i].getId().equals(key)){
					list[i]=null;
					break;
				}
			}
		}
		this.write(list);
	}
	public void updateAuthority(Authority u){
		Authority[] list = this.allAuthority();
		for(int i=0; i<100; i++){
			if(list[i].getId().equals(u.getId())){
				list[i]=u;
				break;
			}
		}
	}
	public Authority searchById(String id){
		Authority[] list = this.allAuthority();
		for(int i=0; i<list.length; i++){
			if(list[i]!=null){
				if(list[i].getId().equals(id)){
					return list[i];
				}
			}
		}
		return null;
	}
	
	public Authority[] allAuthority(){
		FileIo fio = new FileIo();
		String[] data = fio.readData("repository/data/AuthorityData.txt");
		Authority u = new Authority();
		Authority[] list = new Authority[100];
		int i=0;
		for(String str:data){
			if(data[i]!=null){
				list[i]=u.fromAuthority(str);
			}
			i++;
		}
		return list;
	}
	public void write(Authority[] list){
		String[] str = new String[100];
		for(int i=0; i<100; i++){
			if(list[i]!=null){
				str[i] = list[i].toStringAuthority();
			}
		}
		FileIo fio = new FileIo();
		fio.writeData(str,"repository/data/AuthorityData.txt");
	}
}
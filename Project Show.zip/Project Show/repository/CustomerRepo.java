package repository;
import java.lang.*;
import entities.*;
import interfaces.*;
 
public class CustomerRepo{
	public void addCustomer(Customer u){
		Customer[] list = this.allCustomer();
		for(int i=0; i<list.length; i++){
			if(list[i]==null){
				list[i]=u;
				break;
			}
		}
		this.write(list);
	}
	public void removeCustomer(String key){
		Customer[] list = this.allCustomer();
		for(int i=0; i<list.length; i++){
			if(list[i]!=null){
				if(list[i].getId().equals(key)){
					list[i]=null;
					break;
				}
			}
		}
		this.write(list);
	}
	public void updateCustomer(Customer u){
		Customer[] list = this.allCustomer();
		for(int i=0; i<100; i++){
			if(list[i].getId().equals(u.getId())){
				list[i]=u;
				break;
			}
		}
	}
	public Customer searchById(String id){
		Customer[] list = this.allCustomer();
		for(int i=0; i<list.length; i++){
			if(list[i]!=null){
				if(list[i].getId().equals(id)){
					return list[i];
				}
			}
		}
		return null;
	}
	
	public Customer[] allCustomer(){
		FileIo fio = new FileIo();
		String[] data = fio.readData("repository/data/CustomerData.txt");
		Customer u = new Customer();
		Customer[] list = new Customer[100];
		int i=0;
		for(String str:data){
			if(data[i]!=null){
				list[i]=u.fromCustomer(str);
			}
			i++;
		}
		return list;
	}
	public void write(Customer[] list){
		String[] str = new String[100];
		for(int i=0; i<100; i++){
			if(list[i]!=null){
				str[i] = list[i].toStringCustomer();
			}
		}
		FileIo fio = new FileIo();
		fio.writeData(str,"repository/data/CustomerData.txt");
	}
}
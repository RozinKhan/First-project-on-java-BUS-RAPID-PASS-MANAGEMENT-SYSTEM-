package repository;
import java.lang.*;
import entities.*;
import interfaces.*;
 
public class TicketRepo{
	public void addTicket(Ticket u){
		Ticket[] list = this.allTicket();
		for(int i=0; i<list.length; i++){
			if(list[i]==null){
				list[i]=u;
				break;
			}
		}
		this.write(list);
	}
	public void removeTicket(String key){
		Ticket[] list = this.allTicket();
		for(int i=0; i<list.length; i++){
			if(list[i]!=null){
				if(list[i].getId().equals(key)){
					list[i]=null;
					break;
				}
			}
		}
		this.write(list);
	}
	public void updateTicket(Ticket u){
		Ticket[] list = this.allTicket();
		for(int i=0; i<100; i++){
			if(list[i].getId().equals(u.getId())){
				list[i]=u;
				break;
			}
		}
	}
	public Ticket searchById(String id){
		Ticket[] list = this.allTicket();
		for(int i=0; i<list.length; i++){
			if(list[i]!=null){
				if(list[i].getId().equals(id)){
					return list[i];
				}
			}
		}
		return null;
	}
	
	public Ticket[] allTicket(){
		FileIo fio = new FileIo();
		String[] data = fio.readData("repository/data/TicketData.txt");
		Ticket u = new Ticket();
		Ticket[] list = new Ticket[100];
		int i=0;
		for(String str:data){
			if(data[i]!=null){
				list[i]=u.fromTicket(str);
			}
			i++;
		}
		return list;
	}
	public void write(Ticket[] list){
		String[] str = new String[100];
		for(int i=0; i<100; i++){
			if(list[i]!=null){
				str[i] = list[i].toStringTicket();
			}
		}
		FileIo fio = new FileIo();
		fio.writeData(str,"repository/data/TicketData.txt");
	}
}
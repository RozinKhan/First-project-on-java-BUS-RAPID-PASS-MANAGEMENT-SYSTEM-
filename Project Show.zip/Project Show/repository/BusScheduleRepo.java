package repository;
import java.lang.*;
import entities.*;
import interfaces.*;
 
public class BusScheduleRepo{
	public void addBusSchedule(BusSchedule u){
		BusSchedule[] list = this.allBusSchedule();
		for(int i=0; i<list.length; i++){
			if(list[i]==null){
				list[i]=u;
				break;
			}
		}
		this.write(list);
	}
	public void removeBusSchedule(String key){
		BusSchedule[] list = this.allBusSchedule();
		for(int i=0; i<list.length; i++){
			if(list[i]!=null){
				if(list[i].getId().equals(key)){
					list[i]=null;
					break;
				}
			}
		}
		this.write(list);
	}
	public void updateBusSchedule(BusSchedule u){
		BusSchedule[] list = this.allBusSchedule();
		for(int i=0; i<100; i++){
			if(list[i].getId().equals(u.getId())){
				list[i]=u;
				break;
			}
		}
	}
	public BusSchedule searchById(String id){
		BusSchedule[] list = this.allBusSchedule();
		for(int i=0; i<list.length; i++){
			if(list[i]!=null){
				if(list[i].getId().equals(id)){
					return list[i];
				}
			}
		}
		return null;
	}
	
	public BusSchedule[] allBusSchedule(){
		FileIo fio = new FileIo();
		String[] data = fio.readData("repository/data/BusScheduleData.txt");
		BusSchedule u = new BusSchedule();
		BusSchedule[] list = new BusSchedule[100];
		int i=0;
		for(String str:data){
			if(data[i]!=null){
				list[i]=u.fromBusSchedule(str);
			}
			i++;
		}
		return list;
	}
	public void write(BusSchedule[] list){
		String[] str = new String[100];
		for(int i=0; i<100; i++){
			if(list[i]!=null){
				str[i] = list[i].toStringBusSchedule();
			}
		}
		FileIo fio = new FileIo();
		fio.writeData(str,"repository/data/BusScheduleData.txt");
	}
}